import React, { useEffect, useState } from 'react';

function App() {
  const [govData, setGovData] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [editId, setEditId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');

  // Fetch records on mount
  const fetchRecords = () => {
    fetch('http://localhost:5000/api/government-data')
      .then((res) => res.json())
      .then((data) => setGovData(data))
      .catch((err) => console.error("Error fetching data:", err));
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  // Handle adding new record
  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/api/government-data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, description }),
    })
      .then(() => fetchRecords())
      .catch((err) => console.error("Error posting data:", err));
    setTitle('');
    setDescription('');
  };

  // Handle deleting a record
  const handleDelete = (id) => {
    fetch(`http://localhost:5000/api/government-data/${id}`, {
      method: 'DELETE',
    })
      .then(() => fetchRecords())
      .catch((err) => console.error("Error deleting record:", err));
  };

  // Handle initiating edit mode for a record
  const handleEdit = (record) => {
    setEditId(record.id);
    setEditTitle(record.title);
    setEditDescription(record.description);
  };

  // Handle updating a record
  const handleUpdate = (e) => {
    e.preventDefault();
    fetch(`http://localhost:5000/api/government-data/${editId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: editTitle, description: editDescription }),
    })
      .then(() => {
        fetchRecords();
        setEditId(null); // exit edit mode
      })
      .catch((err) => console.error("Error updating record:", err));
  };

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col items-center p-4">
      <h1 className="text-4xl font-bold text-blue-600 mb-4">Government Data</h1>

      {/* Display existing data */}
      <ul className="w-full max-w-2xl">
        {govData.map((item) => (
          <li key={item.id} className="bg-white p-4 rounded shadow mb-2 flex justify-between items-center">
            {editId === item.id ? (
              // Inline edit form for the record
              <form onSubmit={handleUpdate} className="w-full">
                <input
                  className="border border-gray-300 p-2 w-full mb-2"
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  required
                />
                <textarea
                  className="border border-gray-300 p-2 w-full mb-2"
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  required
                />
                <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded mr-2">
                  Update
                </button>
                <button
                  type="button"
                  onClick={() => setEditId(null)}
                  className="bg-gray-500 text-white px-4 py-2 rounded"
                >
                  Cancel
                </button>
              </form>
            ) : (
              <div className="flex justify-between w-full items-center">
                <div>
                  <h2 className="text-xl font-semibold">{item.title}</h2>
                  <p>{item.description}</p>
                </div>
                <div className="flex">
                  <button
                    onClick={() => handleEdit(item)}
                    className="bg-yellow-500 text-white px-4 py-2 rounded mr-2"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="bg-red-500 text-white px-4 py-2 rounded"
                  >
                    Delete
                  </button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>

      {/* Form to add new data */}
      <form onSubmit={handleSubmit} className="bg-white p-4 mt-6 rounded shadow w-full max-w-2xl">
        <h2 className="text-2xl font-bold mb-4">Add a New Record</h2>
        <div className="mb-2">
          <label className="block mb-1 font-semibold">Title</label>
          <input
            className="border border-gray-300 p-2 w-full"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div className="mb-2">
          <label className="block mb-1 font-semibold">Description</label>
          <textarea
            className="border border-gray-300 p-2 w-full"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Add Record
        </button>
      </form>
    </div>
  );
}

export default App;




