// server.js
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Sample in-memory data
let sampleData = [
    { id: 1, title: "Budget 2025", description: "Details on the 2025 budget" },
    { id: 2, title: "Legislation Update", description: "Recent legislative changes" },
    { id: 3, title: "Official Record", description: "Published official records" }
];

// GET endpoint: Retrieve all government data
app.get('/api/government-data', (req, res) => {
    res.json(sampleData);
});

// POST endpoint: Add new record to government data
app.post('/api/government-data', (req, res) => {
    const { title, description } = req.body;
    const newId = sampleData.length + 1;
    const newRecord = { id: newId, title, description };
    sampleData.push(newRecord);
    res.status(201).json({ message: "Record added successfully", newRecord });
});

// DELETE endpoint: Remove a record by id
app.delete('/api/government-data/:id', (req, res) => {
    const recordId = parseInt(req.params.id, 10);
    const index = sampleData.findIndex(item => item.id === recordId);

    if (index === -1) {
        return res.status(404).json({ message: "Record not found" });
    }

    sampleData.splice(index, 1);
    res.json({ message: `Record with id ${recordId} deleted successfully` });
});

app.listen(PORT, () => {
    console.log(`Backend running on http://localhost:${PORT}`);
});

// PUT endpoint: Update an existing record by id
app.put('/api/government-data/:id', (req, res) => {
    const recordId = parseInt(req.params.id, 10);
    const { title, description } = req.body;
    const index = sampleData.findIndex(item => item.id === recordId);

    if (index === -1) {
        return res.status(404).json({ message: "Record not found" });
    }

    // Update the record
    sampleData[index] = { id: recordId, title, description };
    res.json({ message: `Record with id ${recordId} updated successfully`, updatedRecord: sampleData[index] });
});

